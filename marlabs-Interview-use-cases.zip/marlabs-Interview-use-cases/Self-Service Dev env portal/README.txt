Infra setup
1.Create the resource group to deploy the dev environments and related resources.
2.Configure the Azure devops agent on a VM and add it to Azure devops selfhosted agent pool.
3.configure a SPN with relevent access on the azure subscription and use it in the service connection.
3.Create a custom image from the existing dev environment virtual machine and use it for the future setups.
3.Run the azure-terraform pipeline to deploy the self service dev environment.


