Infra setup
1.Create the resource group to deploy the Blogapp and related resources.
2.COnfigure the Azure devops agent on a VM and add it to Azure devops selfhosted agent pool.
3.configure a SPN with relevent access on the azure subscription and use it in the service connection.
3.Run the azure-pipelines-terraform-infra-automation pipeline to deploy the Vnet, subnets, webapp, app gateway, keyvault,storage account and Database
4.configure the required network security group rules between the subnets.
5.configure the scaling rules for the webapp based on the memory/CPU utilization.

CI/CD setup
1.webapp code base is stored in the azure repos.
2.trigger the azure-pipelines-app-deployment to deploy the code to the azure webapp

User Authentication
1.Create a Enterprise application for the webapp
2.configure the SSO for the webapp